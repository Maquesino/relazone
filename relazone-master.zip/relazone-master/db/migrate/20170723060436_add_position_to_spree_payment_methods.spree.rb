# This migration comes from spree (originally 20150522071831)
class AddPositionToSpreePaymentMethods < ActiveRecord::Migration
  def change
    add_column :spree_payment_methods, :position, :integer, default: 0
  end
end
