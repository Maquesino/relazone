Recaptcha.configure do |config|
config.public_key = '6LcauA8TAAAAAGncDdV2pjc8lxWHf7oSiMz9_0OS'  
config.private_key = '6LcauA8TAAAAAJi52ztlkgdTQl9rSO8Y_haSONzO' 
end